//
//  Contact.swift
//  contacts
//
//  Created by Ahmed Abukmail on 6/22/16.
//  Copyright © 2016 UHCL. All rights reserved.
//

import Foundation
class Contact: NSObject, NSCoding {

    var fname: String
    var lname: String
    var phone: String
    var email: String
    var address: String
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(lname, forKey: "last")
        aCoder.encode(fname, forKey: "first")
        aCoder.encode(phone, forKey: "phone")
        aCoder.encode(email, forKey: "email")
        aCoder.encode(address, forKey: "address")
    }
    
    required init (coder aDecoder: NSCoder) {
        
        lname = aDecoder.decodeObject(forKey: "last") as! String
        fname = aDecoder.decodeObject(forKey: "first") as! String
        phone = aDecoder.decodeObject(forKey: "phone") as! String
        email = aDecoder.decodeObject(forKey: "email") as! String
        address = aDecoder.decodeObject(forKey: "address") as! String
    }
    
    
    
    // initializers always have external names added.
    // to remove use _
    init (fname:String, lname:String, phone:String, email:String, address:String) {
        
        self.fname = fname
        self.lname = lname
        self.phone = phone
        self.email = email
        self.address = address
    }
    
    func fullName () -> String{
        return fname + " " + lname
    }
    func contactInfo() -> String{
        return "Name: " + fullName() + "\n" +
            "Phone: " + phone + "\n" + "Email: " + email + " \n" +
            "Address: " + address
    }
    
}
