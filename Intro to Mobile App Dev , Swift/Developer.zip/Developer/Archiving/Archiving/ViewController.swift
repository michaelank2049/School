//
//  ViewController.swift
//  Archiving
//
//  Created by Ahmed Abukmail on 10/26/16.
//  Copyright © 2016 UHCL. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @objc func archive(_ notification: Notification) {
        print("Archiving")
        let path = NSHomeDirectory() + "/Documents/contactNotification.archive"
        NSKeyedArchiver.archiveRootObject(contacts.contacts,
                                          toFile: path)
    }
    
    func archive() {
        let path = NSHomeDirectory() + "/Documents/contacts.archive"
        
        print(path)
        NSKeyedArchiver.archiveRootObject(contacts.contacts, toFile: path)
    }

    
    func unarchive() {
        let path = NSHomeDirectory() + "/Documents/contacts.archive"
        let manager = FileManager.default
        if manager.fileExists(atPath: path) {
            unarchivedContacts.contacts = NSKeyedUnarchiver.unarchiveObject(withFile: path)
                as! [Contact]
        }
    }
    
    @objc func unarchive(_ notification:Notification) {
        print("Unarchiving")
        let path = NSHomeDirectory() + "/Documents/contactNotification.archive"
        let manager = FileManager.default
        if manager.fileExists(atPath: path) {
            unarchivedContacts.contacts = NSKeyedUnarchiver.unarchiveObject(withFile: path)
                as! [Contact]
        
            for i in unarchivedContacts.contacts {
                print("\(i.fname) \(i.lname) \(i.phone) \(i.email) \(i.address) ")
            }
        }
    }
    
    @IBAction func unarchiveAction(_ sender: UIButton) {
        unarchive()
        for i in unarchivedContacts.contacts {
            print("\(i.fname) \(i.lname) \(i.phone) \(i.email) \(i.address) ")
        }

    }
    @IBAction func archiveAction(_ sender: UIButton) {
        archive()
    }
    var contacts = ContactDBModel()
    var unarchivedContacts = ContactDBModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        contacts.loadDatabase()
        
    NotificationCenter.default.addObserver(self, selector: #selector(ViewController.archive(_:)), name: UIApplication.didEnterBackgroundNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.unarchive(_:)), name: UIApplication.didBecomeActiveNotification, object: nil)
        print(NSHomeDirectory())
    }

    deinit {
        NotificationCenter.default.removeObserver(self, name:
            UIApplication.didEnterBackgroundNotification,
                       object: nil)
    }

    
}

