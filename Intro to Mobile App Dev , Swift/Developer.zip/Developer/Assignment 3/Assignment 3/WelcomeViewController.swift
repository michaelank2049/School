//
//  WelcomeViewController.swift
//  Assignment 3
//
//  Created by Lankford, Michael A on 7/16/21.
//

import UIKit

class WelcomeViewController: UIViewController {
    
    @IBOutlet weak var pword: UITextField!  // Entered password variable
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
