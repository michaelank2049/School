//
//  SettingsViewController.swift
//  Assignment4
//
//  Created by Lankford, Michael A on 7/24/21.
//

import UIKit

class SettingsViewController: UIViewController {

    @IBOutlet weak var defaultSpeed: UITextField!       // Variable declarations
    @IBOutlet weak var delay: UITextField!
    @IBOutlet weak var userName: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
