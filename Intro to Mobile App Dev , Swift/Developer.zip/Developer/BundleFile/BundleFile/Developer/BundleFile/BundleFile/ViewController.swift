//
//  ViewController.swift
//  BundleFile
//
//  Created by Lankford, Michael A on 7/20/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displayName: UILabel!
    
    @IBAction func loadNume(_ sender: UIButton) {
        let path = Bundle.main.path(forResource: "bundledata", ofType: "txt")
    }
    
    @IBAction func restore(_ sender: UIButton) {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

