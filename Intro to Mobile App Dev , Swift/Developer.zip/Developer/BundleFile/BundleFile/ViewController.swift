//
//  ViewController.swift
//  BundleFile
//
//  Created by Lankford, Michael A on 7/20/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displayName: UILabel!
    
    @IBAction func loadNume(_ sender: UIButton) {
//        if let path = Bundle.main.path(forResource: "bundleData", ofType: "txt"){
//        //print(pth)
//        //displayName.text = path
//            if let text = try? String(contentsOfFile: path, encoding: String.Encoding.utf8){
//            let a = text.components(separatedBy: "\n")
//                for name in a{
//                    displayName.text = name
//                    print("Hello \(name)")
//                }
//            }
//        }
        
        let defaults = UserDefaults.standard
        let username = "bob"
        let pass = "secret"
        let age = 50
        let employed = true
        //store user info
        defaults.setValue(pass, forKey: "password")
        defaults.setValue(username, forKey: "username")
        defaults.setValue(age, forKey: "age")
        defaults.setValue(employed, forKey: "employed")
        
        let dict = ["name":"bob", "pass":"secret", "age":50, "employed":true] as [String:Any]
        defaults.set(dict, forKey: "allUserInfo")
    }
    
    @IBAction func restore(_ sender: UIButton) {
        let defaults = UserDefaults.standard
        let password = defaults.value(forKey: "password")
        let age = defaults.value(forKey: "age")
        print("The password is \(password) and the age is \(age)")
        let userInfo = defaults.value(forKey: "allUserInfo")
        print(((userInfo as? Dictionary)? ["employed"]!)!)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

