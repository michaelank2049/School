//
//  ContactDetaillViewController.swift
//  ContactsDB
//
//  Created by Lankford, Michael A on 7/7/21.
//

import UIKit

class ContactDetailViewController: UIViewController {

    @IBOutlet weak var first: UITextField!
    @IBOutlet weak var last: UITextField!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var address: UITextView!
    
    var contact: Contact!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        first.text = contact.first
        last.text = contact.last
        phone.text = contact.phone
        email.text = contact.email
        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
           
        
    }

}
