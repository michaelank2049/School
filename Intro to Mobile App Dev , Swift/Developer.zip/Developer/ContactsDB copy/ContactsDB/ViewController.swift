//
//  ViewController.swift
//  ContactsDB
//
//  Created by Lankford, Michael A on 6/29/21.
//

import UIKit

class ContactTableViewController: UITableViewController {
    
    var contacts: ContactDB!
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String {
        return "Contacts"
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count()
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let contactIdentifier = "ContactCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: contactIdentifier, for: indexPath)
        let contact = contacts.contactAtIndex(indexPath.row)
        cell.textLabel!.text = contact.fullName()
        cell.detailTextLabel?.text = "\(contact.email)"
        cell.imageView!.image = UIImage(named: "doge.jpg")
        return cell
    }
    
//    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let contact = contacts.contactAtIndex(indexPath.row)
//        let alert = UIAlertController(title: "\(contact.fullName())", message: contact.contactInfo(), preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "Close", style: .default, handler: {_ in}))
//        self.present(alert, animated: true, completion: {})
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        contacts = ContactDB()
        // Do any additional setup after loading the view.
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if let id = segue.identifier{ // make sure there's an identifier
            switch id{
            case "ContactDetail":
                if let contactDVC = segue.destination as? ContactDetailViewController{
                    let selectedRow = self.tableView.indexPathForSelectedRow?.row
                    contactDVC.contact = contacts.contactAtIndex(selectedRow!)
                }
            default:
                break
            }
        }
    }
    
    @IBAction func save(segue: UIStoryboardSegue){
        if segue.identifier == "SaveUnwindSegue"{
            let dest = segue.source as! AddContactViewController
            contacts.addContact(dest.contact)
            tableView.reloadData()
        }
    }
    
    @IBAction func cancel(segue: UIStoryboardSegue){
        dismiss(animated: true, completion: nil)
    }
}

