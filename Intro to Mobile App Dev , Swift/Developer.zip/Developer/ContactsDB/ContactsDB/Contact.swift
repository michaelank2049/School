//
//  Contact.swift
//  ContactsDB
//
//  Created by Lankford, Michael A on 6/29/21.
//

import Foundation

class Contact{
    var first: String
    var last: String
    var phone: String
    var email: String
    var address: String
    
    init( _ first: String, _ last: String, _ address: String, _ phone: String, _ email: String){
        self.first = first
        self.last = last
        self.phone = phone
        self.email = email
        self.address = address
    }
    
    func fullName() -> String{
        return first + " " + last
    }
    
    func contactInfo() -> String{
        return fullName() + "\n" + address + "\n" + phone + "\n" + email
    }
}
