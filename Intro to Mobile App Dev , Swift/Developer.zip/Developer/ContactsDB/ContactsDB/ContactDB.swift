//
//  ContactDB.swift
//  ContactsDB
//
//  Created by Lankford, Michael A on 6/29/21.
//

import Foundation

class ContactDB{
    
    var contacts: [Contact]
    
    init(){
        contacts = [Contact]()
        loadDatabase()
    }
    
    func contactAtIndex(_ idx: Int) -> Contact{
        return contacts[idx]
    }
    
    func count() -> Int{
        return contacts.count
    }
    
    func loadDatabase(){
        contacts.append(Contact("Bob", "Smith", "2700 Bay Area Blvd Houston, TX 77058", "111-222-3333", "bob@uhcl.edu"))
        contacts.append(Contact("Jim", "Miller", "2701 Bay Area Blvd Houston, TX 77058", "111-222-4444", "jim@uhcl.edu"))
        contacts.append(Contact("George", "Bush", "2702 Bay Area Blvd Houston, TX 77058", "111-222-5555", "george@uhcl.edu"))
    }
    
    func deleteContact(_ idx: Int){
        contacts.remove(at: idx)
    }
    
    func addContact(_ c: Contact){
        contacts.append(c)
    }
}
