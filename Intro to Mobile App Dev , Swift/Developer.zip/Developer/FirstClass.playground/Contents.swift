import UIKit

//var str = "Hello, playground"
//
//var pi = 3.14     // If you use let then the variable will be a constant and can't be changed \ If you use var then the variable can be changed
//pi = pi + 2.3
//
//var x:Int = 5
//x = x + 1
//print(x)
//
//// Like python there are no ; unless you are putting multiple statements on the same line      Ex:  x = x + 1; print(x); x = x + x; print(x)
//
//var name = "Joe"     // var name:String = "Joe"
//name = name + "Doe"
//print(name)
//
//// mixing types
//5 + 4.9
//
//var a = 5
//var b = 4.9
//Double(a) + b    // a+b won't work because it is a double variable trying to be added to an integer variable
//
//var c = 12_3456_789_0    // xCode ignores underscores
//
//// optionals in swift
//var d:Int?    // This declares d as an Int optional
//d = 5
//var e = 10
//
//d! + e    // Use the ! to unwrap optionals
//
//var f:Int!   // automatically unwrapped optional
//f = 20
//
//f + d!
//
//// String types
//var name2:String = "John"
//name2 += " Smith"
//if name2 == "John Smith"
//{
//    print(name2)
//}
//
//let st = "ABC"
//let st2 = String(repeating: "A" , count: 5)
//
//let st3 = String(["a", "b", "c"])
//
//let age = 19
//let myName = "Michael"
//var message = "My name is " + myName + ", I am " + String(age) + " years old"
////String interpolation
//var message2 = "My name is \(myName), I am \(age) years old"
//
//
//
///// Start of Second class------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//print(name)
//name = "joe doe"
//
//name.capitalized
//name.uppercased()
//name.lowercased()
//name = "Michael Lankford CSCI 4377 Student"
//let loc = name.index(name.startIndex, offsetBy: 3)
//print(name[loc])
//name[...loc]
//var str2 = name[loc ..< name.endIndex]
//
//let str3 = "abc def"
//str3.hasSuffix("def")
//let str4 = "a,b,c,d"
//let arr = str4.components(separatedBy: ",")
//arr.joined(separator: "**")
//
//str4.components(separatedBy: ",").joined(separator: "**")
//
//let num = 5.5
//let st5 = "\(num)"
//
//let st6 = "35.7"
//let num2 = Double(st6)
//print(num2!)        //Need ! because num2 is an optional
//
//let value = (st6 as NSString).doubleValue
//value
//var w = 0b1101
//
//let bb = 60
//String(bb, radix: 16)
//print(bb, separator: "", terminator: "")     //How to print without a new line
//print(bb)
//
//let st7 = String(format: "%-15.3f", 312.456785)
//let st8 = String(format: "%-9.7d", 12345)
//
//// trimming
//let someString = "   \t     abcd 123 def 456    \n"
//let trimmedString = someString.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
//
//// Arrays[]
//var newArray = Array<String>()
//var anotherOne = [String]()
//var otherArray:[String] = []
//var arr2 = Array(arrayLiteral: "abc")
//
//
//// work with arrays and their methods
//var salaries = [1000, 2000, 9999.99]
//salaries[0]
//salaries.first
//salaries.last
//salaries.remove(at: 1)
//salaries
//salaries.append(8000)
//salaries.insert(7000, at: 1)
//salaries
//salaries.count
//salaries.reverse()
//
//let someValue = [Int](repeating: 5, count: 10)
//var col = 10
//var row = 5
//var arr2d = [[Int]]()
//for _ in 0..<row
//{
//    let newRow = [Int](repeating: 5, count: col)
//    arr2d.append(newRow)
//}
//
//var array = [1, 2, 3, 4, 5, 6]
//array += [40, 50, 60]
//array
////array.removeSubrange(2...4)
//array.replaceSubrange(2...4, with: [100, 200])
//array.insert(contentsOf: [90, 80], at: 4)
//
//var abc = [2, 3, 4]
//var def = abc
//abc = []
//
//let abc2 = array[1..<4]
//abc2
//
//for i in 0...3
//{
//    print(array[i])
//}
//
//// How to safely deal with optionals
//let array2 = [100, 80, 40, 30, 20, 1000]
//if let index = array2.firstIndex(of: 20)
//{
//    print(index)
//}
//else
//{
//    print("not there")
//}
//
//let otherString = "123.5"
//
//if let value2 = Double(otherString)
//{
//    print(value2)
//}
//else
//{
//    print("Illegal format")
//}
//// How to safely deal with optionals end
//
//// How do i sort an array. <TYPE>
//var arr10 = [400, 1000, 50, 90]
//
////arr10.sort{ $0 < $1 }     // a closure lambda calculus. I don't need to know the name of a function, just what it takes and what it does and what it returns.
//
//arr10.sort()
//arr10


// Start of class 3----------------------------------------------------------------------------------------------------
//let y = 90
//let a = [3, 4, 1, 2, 5]
//var b = a.reduce(y, {$0 + $1})
//b = a.reduce(1, {$0 * $1})
//b = a.reduce(0, {$0 + $1 * $1})
//
////  maps and filters
//var newArray = a.map{$0 + $0}
//newArray = a.filter{#0 % 2 == 0}

// dictionaries
//var salaries = [String:Int]()
//salaries = ["bob":10000, "Ed":20000, "Jim":5000]
//salaries["bob"] = 40000
//print(salaries["Ed"]!)
//salaries
//salaries["James"] = 1000
////salaries.removeAll()
////salaries = [:]
////salaries.isEmpty
//salaries
////salaries.removeValue(forKey: "Jim")
//salaries["Jim"] = nil
//salaries
//// count, first, last ... work with dictionaries, arrays, and strings

// Tuples
//let x = (size: 8900, inTexas: true, city: "Houston", name: "uhcl")
//var (size, _, _, city) = x
//size
//city

// if statement
//var x = 10
//if x >= 3 && x % 2 == 0
//{
//    print(x)
//    x = x - 1
//}
//
//if x <= 3
//{
//    print(x)
//}
//else if x > 3
//{
//    print(x+3)
//}
//else
//{
//    print(x - 3)
//}
//
//var n = 0
//repeat
//{
//    n = n + 1
//    print(n)
//}while n < 10;

//for i in (0 ..< 4).reversed()
//{
//    print(i)
//}
//
//let names = ["Bob", "Ed", "John"]
//for name in names
//{
//    print(name)
//}
//
//var salaries = ["bob":10000, "Ed":20000, "Jim":5000]
//var str3 = Array<String>()
//for(name, salary) in salaries
//{
//    print("\(name) makes $\(salary) per year")
//}
//str3
//
//let nums = [2, 3, 8, 9, 1]
//for num in nums{
//    print(num)
//}
//
//for key in salaries.keys{
//    print("Name: \(key) Salary: \(salaries[key]!)")
//}

// functions in Swift
// func <name of function> (list of parameters) [-> return type] {body}
//func theResultOfAdding(_ first:Int, to second:Int) -> Int{
//    return first + second
//}
//
//// first and second are called internal paramter names
//
//let y = theResultOfAdding( 5, to: 3)

//func calcStats(_ scores:[Int]) -> (min:Int, max:Int, sum:Int, sumIsOdd: Bool){
//    var min = scores[0]
//    var max = scores[0]
//    var sum = 0
//    for s in scores{
//        if s > max{
//            max = s
//        }
//        if s < min{
//            min = s
//        }
//        sum += s
//    }
//    var isOdd = false
//    if sum % 2 != 0{
//        isOdd =  true;
//    }
//    return(min, max, sum, isOdd)
//}
//
//let stats = calcStats([5, 3, 100, 3, 9])
//stats.min
//stats.sumIsOdd
//stats.2

// structures, enumerations, and classes
//struct Complex{
//    var real: Double
//    var imag: Double
//}
//
//enum Seasons{
//    case Spring
//    case Summer
//    case Winter
//    case Fall
//}
//
//var currentSeason = Seasons.Summer
//var nextSeason: Seasons = .Fall
//var x: Seasons
//x = .Spring
//
//switch currentSeason{
//case .Spring:
//    print("Nice Weather")
//    fallthrough
//case .Summer:
//    print("hot")
//case .Winter:
//    print("Maybe cold")
//default:
//    print("")      //Switch cases need a default in swift
//}

class Employee{
    // properties of the Employee class
    var name:String
    var id:Int
    var rate:Double{
        willSet{
            print("About to change the rate to \(newValue)")
        }
        didSet{
            print("Old value \(oldValue) is changed to \(rate)")
        }
    }
    var hours:Double
    var annualPay:Double{
        get{
            return self.rate * 2080
        }
        set{
            self.rate = newValue / 2080
        }
    }
    
    init(name:String, id:Int, rate:Double, hours:Double, annualPay:Double){
        self.name = name
        self.id = id
        self.rate = rate
        self.hours = hours
        self.annualPay = annualPay
    }
    
    init(name:String, id:Int, rate:Double){
        self.name = name
        self.id = id
        self.rate = rate
        self.hours = 0
        self.annualPay = 0
    }
    
    func salary() -> Double{
        if hours < 40{
            return hours * rate
        }
        
        return (hours - 40) * rate * 1.5 + 40 * rate
    }
    
}

var e = Employee(name: "Michael", id: 123, rate: 10.0, hours: 45, annualPay: 20800)
e.name = "Michael"
e.salary()

// can you change my salary by modifying the rate?
//e.rate = 20
e.salary()

// can you change my rate by modifying my salary?
e.annualPay
e.rate

e.annualPay = 41600
e.rate
e.salary()
//Property Observer

// Employee is a class and e is an object of that class. "Any"

class HourlyEmployee: Employee{    //Swift only allows single inheritance
    
}
// an hourly employee is an employee

class FullTimeEmployee: Employee{
    
}

class PartTimeEmployee: Employee{
    
}

// if one of my functions is expecting an employee class they are expecting the parent class

func xyz (e:Employee){
//    if e is PartTimeEmployee{
//
//    }
//    else if e is FullTimeEmployee{
//
//    }
    
    // object casting
    if let obj = e as? PartTimeEmployee{
        
    }
}



