//
//  ViewController.swift
//  Greeting
//
//  Created by Lankford, Michael A on 6/18/21.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var name: UITextField!
    
    
    @IBOutlet weak var timeOfDay: UISegmentedControl!
    
    
    @IBOutlet weak var message: UILabel!
    
    
    @IBAction func showMessage(_ sender: Any) {
        var userName = "Stranger"
        if name.text != ""{
            userName = name.text!
        }
        
        if timeOfDay.selectedSegmentIndex == 0{
            message.text = "Good morning, " + userName
        }
        else if timeOfDay.selectedSegmentIndex == 1{
            message.text = "Good afternoon, " + userName
        }
        else{
            message.text = "Good evening, " + userName
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == name{
            textField.resignFirstResponder()
        }
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        name.resignFirstResponder()
        self.view.endEditing(true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        name.becomeFirstResponder()
        self.name.delegate = self
        // Do any additional setup after loading the view.
    }


}

