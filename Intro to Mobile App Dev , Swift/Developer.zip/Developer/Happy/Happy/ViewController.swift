//
//  ViewController.swift
//  Happy
//
//  Created by Lankford, Michael A on 7/21/21.
//

import UIKit

class ViewController: UIViewController, FaceViewDataSource {
    func smilinessForHappiness(_sender: FaceView) -> Double? {
        return Double(happiness - 50) / 50
    }
    
    @IBAction func changeHappiness(_ sender: UIPanGestureRecognizer) {
        switch sender.state{
        case .ended:
            fallthrough
            
        case .changed:
            let translation = sender.translation(in: faceView)
            let happinessChange = -Int(translation.y) / 4
            if happiness != 0{
                happiness += happinessChange
                sender.setTranslation(CGPoint.zero, in: faceView)
            }
        default:
            break
        }
    }
    
    @IBAction func changeColor(_ sender: UITapGestureRecognizer) {
        switch sender.state{
        case .ended:
            fallthrough
            
        case .changed:
            if faceView.color == UIColor.red{
                faceView.color = UIColor.green
            }
            else if faceView.color == UIColor.green{
                faceView.color = UIColor.systemBlue
            }
            else{
                faceView.color = UIColor.red
            }
        default:
            break
        }
    }
    var happiness: Int = 50{
        didSet{
            happiness = min(max(happiness, 0), 100)
            faceView.setNeedsDisplay()
        }
    }
    
    @IBOutlet var faceView: FaceView!{
        didSet{
            self.faceView.dataSource = self
            faceView.addGestureRecognizer(UIPinchGestureRecognizer(target: faceView, action: Selector("scale:")))
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

