//
//  ViewController.swift
//  TabbedApp
//
//  Created by Lankford, Michael A on 7/7/21.
//

import UIKit

class FirstViewController: UIViewController {

    var x = 5
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        (self.tabBarController?.viewControllers?[1] as! SecondViewController).y += 1
        print(x)
        
        let a = (UIApplication.shared.delegate as! AppDelegate).delegateVar + 10
        
        print(a)
    }
}

