//
//  SecondViewController.swift
//  TabbedApp
//
//  Created by Lankford, Michael A on 7/7/21.
//

import UIKit

class SecondViewController: UIViewController {

    var y = 10
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    override func viewDidAppear(_ animated: Bool) {
        (self.tabBarController?.viewControllers?[0] as! FirstViewController).x += 1
        print(y)
        
        let a = (UIApplication.shared.delegate as! AppDelegate).delegateVar + 10
        
        print(a)
    }
}
