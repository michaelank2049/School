import UIKit

/*
extension String{
    func substring(_ x: CountableRange<Int>) -> String?{
        if x.lowerBound < 0 || x.upperBound > self.count || x.lowerBound > self.count || x.upperBound < 0{
            return nil
        }
        let loc1 = self.index(self.startIndex, offsetBy: x.lowerBound)
        let loc2 = self.index(self.startIndex, offsetBy: x.upperBound)
        return String(self[loc1..<loc2])
    }
    func substring(_ x: CountableClosedRange<Int>) -> String?{
        if x.lowerBound < 0 || x.upperBound > self.count || x.lowerBound > self.count || x.upperBound < 0{
            return nil
        }
        let loc1 = self.index(self.startIndex, offsetBy: x.lowerBound)
        let loc2 = self.index(self.startIndex, offsetBy: x.upperBound)
        return String(self[loc1...loc2])
    }
}

let x = "ahmedabukmailatuh-clear lake"
"ahmedabukmailatuh-clearlake".substring(7...15)
"ahmedabukmailatuh-clearlake".substring(7..<15)

var n: Int = 10
for _ in 1...n{
    print("hello")
}

func fib(_ x: Int) -> Int{
    if x <= 1{
        return x
    }
    return fib(x - 1) + fib(x - 2)
}

fib(6)

var y = 5
func inc(_ x: inout Int){
    print("x before the increment \(x)")
    x = x + 1
    print("x after the increment \(x)")
}
print("y before the increment \(y)")
inc(&y)
print("y after the increment \(y)")

strtod("855.233", nil)
strtoul("1F", nil, 16)

//enums with associated values
func speed(_ brand: String) -> Int{
    if brand == "honda"{
        return 6
    }else if brand == "toyota"{
        return 5
    }else{
        return 10
    }
}

var spd: (String) -> Int
spd = speed
spd("honda")
speed("honda")

enum Vehicle{
    case Truck(Int, String) // Capacity Brand
    case Car(Bool, Bool, String) // sedan or not, manual or not, brand
    case Bike(String, (String) -> Int) // brand, and a function or closure
}

var v: Vehicle
v = .Bike("honda", spd)
var v2: Vehicle
v2 = .Car(true, true, "toyota")

var a = [Vehicle]() // Array<Vehicle>()
a.append(v)
a.append(v2)
switch v{
case .Truck(let cap, let brand):
    print("\(cap) \(brand)")
case .Car(let sed, let auto, let brand):
    print("\(sed) \(auto) \(brand)")
case .Bike(let brand, let s):
    print("\(brand)")
    let y = s(brand)
    print("y = \(y)")
}


enum Seasons: Int{
    case spring, summer, fall, winter
}

var s: Seasons = .winter
s.rawValue

enum Optional<Type>{
    case none
    case some(Type)
}

let xx = Optional<String>.none
let yy = Optional<String>.some("Hello")

//let's discuss protocols.
protocol PP{
    var a: String{set get}
}

protocol Q{
    var name: String{ get}
}

class NewType: PP{
    var a: String = ""
    var b: Int = 0
}

class Person: Q{
    var title: String?
    var fname: String
    var lname: String
    init(_ sal: String? = nil, first: String, last: String){
        title = sal
        fname = first
        lname = last
    }
    
    var name: String{
        return (title == nil ? "" : title!) + " " + fname + " " + lname
    }
}

let aa = Person(first: "Ahmed", last: "Abukmail")
let bb = Person("Mr.", first: "Ahmed", last: "Abukmail")
aa.name
bb.name

protocol StaticProto{
    static var tp: Int{get set}
}

class WithStatic: StaticProto{
    static var tp: Int = 0
}

class B {
    var a: Int
    var y: Int
    init(x: Int){
        a = x
        y = x
    }
}

protocol WithMethods{
    func func1()
    func func2(x: String) -> Int
    init(x : Int)
}

class A : B, WithMethods{
  
    required override init(x: Int){
        super.init(x: 2)
        y = x
    }
    
    func func1(){
        print("hello")
    }
    
    func func2(x: String) -> Int{
        return x.count
    }
}

protocol Browsable{
    func browse(s: String)
}

protocol Editable{
    func edit(x: Int)
}

class Website: Browsable, Editable{
    func browse(s: String) {
        print(s)
    }
    
    func edit(x: Int) {
        print(x)
    }
}

class DigitalLibrary: Browsable, Editable{
    func browse(s: String) {
        print(s)
        print("hello")
    }
    
    func edit(x: Int) {
        print(x)
        print("hi")
    }
}

class Settings: Editable{
    func edit(x: Int){
        print("The value of x is \(x)")
    }
}

class Document: Editable{
    func edit(x: Int){
        print("The value of x from document is \(x)")
    }
}

var google: Website = Website()
var blueTooth: Settings = Settings()
var wordDoc: Document = Document()
var acm: DigitalLibrary = DigitalLibrary()
var p2: Browsable & Editable
p2 = google
var p3 = [Browsable & Editable]()
p3.append(google)
p3.append(acm)
var p1: Editable = blueTooth
var p4: Editable = wordDoc
var p5 = [Editable]()
p5.append(p1)
p5.append(p4)

func f2(x: Browsable & Editable){
    x.browse(s: "Ahmed")
    print("function done")
}

f2(x: google)

struct StructDef: Editable{
    func edit(x: Int){
        print("hello")
    }
}

protocol EditableClassOnly: class{
    func edit(x: Int)
}

class P: EditableClassOnly{
    func edit(x: Int){
        print(x)
    }
}

class TmpClass{
    var st: String
    var i: Int
    init(s: String, i: Int){
        self.st = s
        self.i = i
    }
    init(){
        st = ""
        i = 0
    }
}

var tc = [TmpClass]()
tc.append(TmpClass(s: "H", i: 10))
tc.append(TmpClass(s: "H", i: 4))
tc.append(TmpClass(s: "H", i: 9))
tc.append(TmpClass(s: "H", i:30))

tc.sort(by: {$0.i < $1.i})
tc[0].i
tc[1].i
tc[2].i


class PersonA{
    let name: String
    init(name: String){
        self.name = name
        print("\(name) is being initialized")
    }
    deinit{
        print("\(name) is being deinitiliazed")
    }
}

var r1: PersonA?
var r2: PersonA?
var r3: PersonA?

r1 = PersonA(name: "Ahmed Abukmail")
r2 = r1
r3 = r1

r1 = nil
r2 = nil
print("*********")
r3 = nil
*/

/*
class Person{
    let name: String
    init(name: String){
        self.name = name
    }
    var apartment: Apartment?
    deinit{
        print("\(name) is being deinitiliazed")
    }
}

class Apartment{
    let unit: String
    init(unit: String){
        self.unit = unit
    }
    var tenant: Person?
    deinit{
        print("Apartment \(unit) is being deinitialized")
    }
}

var john: Person?
var unit4A: Apartment?

john = Person(name: "Ahmed")
unit4A = Apartment(unit: "4A")

john!.apartment = unit4A
unit4A!.tenant = john

john = nil
unit4A = nil
*/

//class Customer{
//    let name: String
//    var card: CreditCard?
//    init(name: String){
//        self.name = name
//    }
//    deinit{
//        print("\(name) is being deinitialized")
//    }
//}
//
//class CreditCard{
//    let number: UInt64
//    unowned let customer: Customer
//    init(number: UInt64, customer: Customer){
//        self.number = number
//        self.customer = customer
//    }
//    deinit{
//        print("Card #\(number) is being deinitialized")
//    }
//}

if let url = URL(string: "http://www.apple.com"){
    do{
        let contents = try? String(contentsOf: url, encoding: String.Encoding.utf8)
        print(contents ?? "None")
        
    }
    catch{
        
    }
}
