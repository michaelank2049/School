#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

int main(){

    //Label statement to return from a 0 system call
    Begin:
        int fd1, fd2, pid, sysCall, numIn, serverInNum, clientNum, length;
        char fifoName[200] = "/tmp/fifoClient";
        char fifoNum[200], in[200], num[200], stringIn[200], serverInString[200];
        int numPar = 1;

        //Ask user for system call input and create client side specific fifo
        printf("Enter a client number: \n");
        scanf("%d", &clientNum);
        sprintf(fifoNum, "%d", clientNum);
        strcat(fifoName, fifoNum);
        char* readFifo = fifoName;
        mkfifo(readFifo, 0666);

        //Create main fifo and send the client side fifo name
        char* writeFifo = "/tmp/mainFifo";
        mkfifo(writeFifo, 0666);
        fd1 = open(writeFifo, O_WRONLY);
        pid = getpid();
        write(fd1, fifoName, sizeof(fifoName));
    
    while(1){

        numPar = 1;

        //Open the write fifo to talk to server
        fd1 = open(writeFifo, O_WRONLY);

        //Ask user for system call input
        printf("Enter a system  call: \n1-Server Request \n2-Number to Text \n3-Text to Number \n4-Store \n5-Recall \n0-Exit \n-1-Terminate: \n");
        scanf("%d", &sysCall);

        if(sysCall == 1){//-------------------------------------------------------------------------------------------------------------------------------------------

            length = 5;

            //Write to server the pid, system call, amount of parameters
            write(fd1, &pid, sizeof(int));
            write(fd1, &sysCall, sizeof(int));
            write(fd1, &numPar, sizeof(int));
            write(fd1, &length, sizeof(int));
            close(fd1);

            //Open server to client and output anyything read
            fd2 = open(readFifo, O_RDONLY);
            read(fd2, in, sizeof(in));
            printf("%s\n", in);
            close(fd2);

        } else if(sysCall == 2){//------------------------------------------------------------------------------------------------------------------------------------

            length = 4;

            //Output message and check to see if user input valid / If yes then write to server / If no outut error message
            while(1){
                printf("Enter your number(must be from 0 to 9): \n");
                scanf("%d", &numIn);
                if (numIn < 0 || numIn > 9){
                    printf("Error. Number must be from 0 to 9.\n");
                }
                else{
                    write(fd1, &pid, sizeof(int));
                    write(fd1, &sysCall, sizeof(int));
                    write(fd1, &numPar, sizeof(int));
                    write(fd1, &numIn, sizeof(int));
                    write(fd1, &length, sizeof(int));
                    break;
                }
            }
            close(fd1);

            //Open server to client and output anyything read
            fd2 = open(readFifo, O_RDONLY);
            read(fd2, in, sizeof(in));
            printf("%d was converted to %s\n\n", numIn, in);
            close(fd2);

        }else if(sysCall == 3){//-------------------------------------------------------------------------------------------------------------------------------------

            //Output message and check to see if user input valid / If yes then write to server / If no outut error message 
            while(1){
                printf("Type your number in lowercase(must be from zero to nine): \n");
                scanf("%s", num);
                if (strcmp(num, "zero") == 0 || strcmp(num, "one") == 0 || strcmp(num, "two") == 0 || strcmp(num, "three") == 0 || strcmp(num, "four") == 0 || strcmp(num, "five") == 0 || 
                    strcmp(num, "six") == 0 || strcmp(num, "seven") == 0 || strcmp(num,"eight") == 0 || strcmp(num,"nine") == 0){
                    write(fd1, &pid, sizeof(int));
                    write(fd1, &sysCall, sizeof(int));
                    write(fd1, &numPar, sizeof(int));
                    write(fd1, num, sizeof(num));
                    close(fd1);
                    break;
                }
                else{
                    printf("Error. Number must be from zero to nine.\n");
                }
            }
            close(fd1); 

            //Open server to client and output anyything read
            fd2 = open(readFifo, O_RDONLY);
            read(fd2, &serverInNum, sizeof(int));
            printf("%s was converted to %d\n\n", num, serverInNum);
            close(fd2);

        }else if(sysCall == 4){//---------------------------------------------------------------------------------------------------------------------------------------

            //Output message and check to see if user input valid / If yes then write to server / If no outut error message
            while(1){
                printf("Enter your value to be stored: \n");
                if (scanf("%d", &numIn)){
                    write(fd1, &pid, sizeof(int));
                    write(fd1, &sysCall, sizeof(int));
                    write(fd1, &numPar, sizeof(int));
                    sprintf(stringIn, "%d", numIn);
                    write(fd1, stringIn, sizeof(stringIn));
                    break;

                }else if(scanf("%s", stringIn)){
                    write(fd1, &pid, sizeof(int));
                    write(fd1, &sysCall, sizeof(int));
                    write(fd1, &numPar, sizeof(int));
                    write(fd1, stringIn, sizeof(stringIn));
                    break;

                }
            }
            close(fd1);

            //Open server to client and output anyything read
            fd2 = open(readFifo, O_RDONLY);
            read(fd2, serverInString, sizeof(serverInString));
            printf("%s was stored in the server.\n\n", serverInString);
            close(fd2);

        }else if(sysCall == 5){//--------------------------------------------------------------------------------------------------------------------------------------

            numPar = 0;
            //Output message and check to see if user input valid / If yes then write to server / If no outut error message
            write(fd1, &pid, sizeof(int));
            write(fd1, &sysCall, sizeof(int));
            write(fd1, &numPar, sizeof(int));
            close(fd1);

            //Open server to client and output anyything read
            fd2 = open(readFifo, O_RDONLY);
            read(fd2, serverInString, sizeof(serverInString));
            printf("%s was retrieved from the server.\n\n", serverInString);
            close(fd2);

        }else if(sysCall == 0){//-----------------------------------------------------------------------------------------------------------------------------------------
            
            numPar = 0;
            //Output message and check to see if user input valid / If yes then write to server / If no outut error message
            write(fd1, &pid, sizeof(int));
            write(fd1, &sysCall, sizeof(int));
            write(fd1, &numPar, sizeof(int));

            //Close fifo and unlink / Jump back to top 
            printf("\n");
            close(fd1);
            unlink(readFifo);
            unlink(writeFifo);
            goto Begin;

        }else if(sysCall == -1){//--------------------------------------------------------------------------------------------------------------------------------------------

            numPar = 0;
            //Output message and check to see if user input valid / If yes then write to server / If no outut error message
            write(fd1, &pid, sizeof(int));
            write(fd1, &sysCall, sizeof(int));
            write(fd1, &numPar, sizeof(int));

            //Cose fifo and unlink / Terminate program
            printf("\n");
            close(fd1);
            unlink(readFifo);
            unlink(writeFifo);
            exit(0);

        }else{
            printf("Invalid System Call.\n\n");
        }
        
    }
    return 0;
    
}
