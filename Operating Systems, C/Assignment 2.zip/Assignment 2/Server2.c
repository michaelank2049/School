#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

int main(){

    //Label statement to return from a 0 system call
    Begin:
        int fd1, fd2, pid, sysCall, numParam, num, length, pidReference;
        char notApplicable[200], fifoName[200], stringIn[200], storedString[200];
        int pidStore[200];
        int count = 1;

        //Create read fifo from client
        char* readFifo = "/tmp/mainFifo";
        mkfifo(readFifo, 0666);

        //Create variable for write fifo
        char* writeFifo;
        
    while(1){
        //Variables to convert pid to the full write fifo file path
        char fifoNameFull[200] = "/tmp/fifoClient";
        char fifoNum[200];
    
        //Open the read fifo
        fd1 = open(readFifo, O_RDONLY);

        //Read system call and number of parameters
        read(fd1, &sysCall, sizeof(int));
        read(fd1, &numParam, sizeof(int));

        if(sysCall == 1){//-------------------------------------------------------------------------------------------------------------------------------------------

            //Read the fifo name, the pid, and the length
            read(fd1, fifoName, sizeof(fifoName));
            read(fd1, &pid, sizeof(int));
            read(fd1, &length, sizeof(int));

            //Store pid for further use
            pidStore[count] = pid;
            
            //Create write fifo to client
            writeFifo = fifoName;
            mkfifo(writeFifo, 0666);
            
            //Output the process id, system call, number of parameters, and fifo name
            printf("1. Process ID: %d\n", pidStore[count]);
            printf("2. System Call Number: %d\n", sysCall);
            printf("3. Number 'n' of parameters: %d\n", numParam);
            printf("4. Size of parameter: %d\n", length);
            printf("5. The fifo the client created is named: %s\n\n", fifoName);

            //Close the read fifo
            close(fd1);

            //Open and close fifo to jump back to client
            fd2 = open(writeFifo, O_WRONLY);
            write(fd2, &count, sizeof(int));
            close(fd2);
            
            //Increment counter for next element to store client pid
            count++;

        }else if(sysCall == 2){//-------------------------------------------------------------------------------------------------------------------------------------
            
            //Read the pid reference number, num, and length
            read(fd1, &pidReference, sizeof(int));
            read(fd1, &num, sizeof(int));
            read(fd1, &length, sizeof(int));

            //Output the process id, system call, number of parameters, and array of parameters
            printf("1. Process ID: %d\n", pidStore[pidReference]);
            printf("2. System Call Number: %d\n", sysCall);
            printf("3. Number 'n' of parameter: %d\n", numParam);
            printf("4. Size of parameter: %d\n", length);
            printf("5. Value for the 'n' parameter: %d\n\n", num);

            //Close the read fifo
            close(fd1);

            //Reassign the write fifo to the correct one
            sprintf(fifoNum, "%d", pidStore[pidReference]);
            strcat(fifoNameFull, fifoNum);
            writeFifo = fifoNameFull;
            mkfifo(writeFifo, 0666);

            //Open the server to client fifo, send the converted value to the client, then close the fifo when done
            fd2 = open(writeFifo, O_WRONLY);
            switch(num){
                case 0:
                    write(fd2, "zero", strlen("zero")+1);
                    break;
                case 1:
                    write(fd2, "one", strlen("one")+1);
                    break;
                case 2:
                    write(fd2, "two", strlen("two")+1);
                    break;
                case 3:
                    write(fd2, "three", strlen("three")+1);
                    break;
                case 4:
                    write(fd2, "four", strlen("four")+1);
                    break;
                case 5:
                    write(fd2, "five", strlen("five")+1);
                    break;
                case 6:
                    write(fd2, "six", strlen("six")+1);
                    break;
                case 7:
                    write(fd2, "seven", strlen("seven")+1);
                    break;
                case 8:
                    write(fd2, "eight", strlen("eight")+1);
                    break;
                case 9:
                    write(fd2, "nine", strlen("nine")+1);
                    break;
                default:
                    write(fd2, "Invalid number.", strlen("Invalid number.")+1);
                    printf("error");
                    break;
            }
            close(fd2); 

        }else if(sysCall == 3){//------------------------------------------------------------------------------------------------------------------------------------
            
            //Read the pid reference number and input string
            char in[200];
            read(fd1, &pidReference, sizeof(int));
            read(fd1, in, sizeof(in));

            //Output the process id, system call, number of parameters, and array of parameters
            printf("1. Process ID: %d\n", pidStore[pidReference]);
            printf("2. System Call Number: %d\n", sysCall);
            printf("3. Number 'n' of parameters: %d\n", numParam);
            printf("4. Size of parameter: %d\n", (int)strlen(in));
            printf("5. Value for the 'n' parameter: %s\n\n", in);

            //Close read fifo
            close(fd1);

            //Reassign the write fifo to the correct one
            sprintf(fifoNum, "%d", pidStore[pidReference]);
            strcat(fifoNameFull, fifoNum);
            writeFifo = fifoNameFull;
            mkfifo(writeFifo, 0666);

            //Open the server to client fifo, send the converted value to the client, then close the fifo when done
            fd2 = open(writeFifo, O_WRONLY);
            if(strcmp(in, "zero") == 0){
                int num = 0;
                write(fd2, &num, sizeof(int));
            }else if(strcmp(in, "one") == 0){
                int num = 1;
                write(fd2, &num, sizeof(int));
            }else if(strcmp(in, "two") == 0){
                int num = 2;
                write(fd2, &num, sizeof(int));
            }else if(strcmp(in, "three") == 0){
                int num = 3;
                write(fd2, &num, sizeof(int));
            }else if(strcmp(in, "four") == 0){
                int num = 4;
                write(fd2,&num, sizeof(int));
            }else if(strcmp(in, "five") == 0){
                int num = 5;
                write(fd2, &num, sizeof(int));
            }else if(strcmp(in, "six") == 0){
                int num = 6;
                write(fd2, &num, sizeof(int));
            }else if(strcmp(in, "seven") == 0){
                int num = 7;
                write(fd2, &num, sizeof(int));
            }else if(strcmp(in, "eight") == 0){
                int num = 8;
                write(fd2, &num, sizeof(int));
            }else if(strcmp(in, "nine") == 0){
                int num = 9;
                write(fd2, &num, sizeof(int));
            }
            close(fd2); 

        }else if(sysCall == 4){//--------------------------------------------------------------------------------------------------------------------------------------------
            
            //Read the pid reference number and input string
            read(fd1, &pidReference, sizeof(int));
            read(fd1, stringIn, sizeof(stringIn));

            //Output the process id, system call, number of parameters, and array of parameters
            printf("1. Process ID: %d\n", pidStore[pidReference]);
            printf("2. System Call Number: %d\n", sysCall);
            printf("3. Number 'n' of parameter: %d\n", numParam);
            printf("4. Size of parameter: %d\n", (int)strlen(stringIn));
            printf("5. Value for the 'n' parameter: %s\n\n", stringIn);

            //Store the string for later use
            strcpy(storedString, stringIn);

            //Close the read fifo
            close(fd1);

            //Reassign the write fifo to the correct one
            sprintf(fifoNum, "%d", pidStore[pidReference]);
            strcat(fifoNameFull, fifoNum);
            writeFifo = fifoNameFull;
            mkfifo(writeFifo, 0666);

            //Open the server to client fifo, acknowledge the stored value to the client
            fd2 = open(writeFifo, O_WRONLY);
            write(fd2, storedString, sizeof(storedString));
            close(fd2);

        }else if(sysCall == 5){//--------------------------------------------------------------------------------------------------------------------------------------------

            //Read the pid reference number
            read(fd1, &pidReference, sizeof(int));

            //Output the process id, system call, number of parameters, and array of parameters
            printf("1. Process ID: %d\n", pidStore[pidReference]);
            printf("2. System Call Number: %d\n", sysCall);
            printf("3. Number 'n' of parameter: %d\n\n", numParam);

            //Close the read fifo
            close(fd1);

            //Reassign the write fifo to the correct one
            sprintf(fifoNum, "%d", pidStore[pidReference]);
            strcat(fifoNameFull, fifoNum);
            writeFifo = fifoNameFull;
            mkfifo(writeFifo, 0666);

            //Open the server to client fifo, send the stored value to the client
            fd2 = open(writeFifo, O_WRONLY);
            write(fd2, storedString, sizeof(storedString));
            close(fd2);

        }else if(sysCall == 0){//--------------------------------------------------------------------------------------------------------------------------------------------

            //Read the pid reference number
            read(fd1, &pidReference, sizeof(int));

            //Output the process id, system call, number of parameters, and array of parameters
            printf("1. Process ID: %d\n", pidStore[pidReference]);
            printf("2. System Call Number: %d\n", sysCall);
            printf("3. Number 'n' of parameter: %d\n\n", numParam);

            //Close the read fifo
            close(fd1);

            //Jump back to the top
            goto Begin;

        }else if(sysCall == -1){//-------------------------------------------------------------------------------------------------------------------------------------------

            //Read the pid reference number
            read(fd1, &pidReference, sizeof(int));

            //Output the process id, system call, number of parameters, and array of parameters
            printf("1. Process ID: %d\n", pidStore[pidReference]);
            printf("2. System Call Number: %d\n", sysCall);
            printf("3. Number 'n' of parameter: %d\n", numParam);

            //Close the read fifo
            close(fd1);

            //Reassign the write fifo to the correct one
            sprintf(fifoNum, "%d", pidStore[pidReference]);
            strcat(fifoNameFull, fifoNum);
            writeFifo = fifoNameFull;
            mkfifo(writeFifo, 0666);

            //Unlink fifos and terminate the program
            unlink(writeFifo);
            unlink(readFifo);
            exit(0); 
        }
    }
    return 0;
    
}





