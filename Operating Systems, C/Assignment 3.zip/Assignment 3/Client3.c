#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

void flushstdin(void)
{
    int c;
    while((c = getchar()) != '\n' && c != EOF);
}



int main(){

    Begin:
        int fd1, fd2, pid, sysCall, numIn, serverInNum, length, pidReference, msgType;
        char fifoName[200] = "/tmp/fifoClient";
        char fifoNum[200], in[200], num[200], stringIn[200], serverInString[200];
        int numPar = 1;

        //Create read fifo name
        pid = getpid();
        sprintf(fifoNum, "%d", pid);
        strcat(fifoName, fifoNum);

        //Create read fifo from server
        char* readFifo = fifoName;
        mkfifo(readFifo, 0666); 

        //Create write fifo to server
        char* writeFifo = "/tmp/mainFifo";
        mkfifo(writeFifo, 0666);
    
    while(1){

        numPar = 1;

        //Open the write fifo to talk to server
        fd1 = open(writeFifo, O_WRONLY);

        //Ask user for system call input
        printf("Enter a system  call: \n1-Server Request \n2-Send Message \n3-Receive Message \n-1-Terminate: \n");
        scanf("%d", &sysCall);

        flushstdin();

        if(sysCall == 1){//-------------------------------------------------------------------------------------------------------------------------------------------

            length = 5;

            //Write to server the psystem call, number of parameters, fifo name, pid, and length
            write(fd1, &sysCall, sizeof(int));
            write(fd1, &numPar, sizeof(int));
            write(fd1, fifoName, sizeof(fifoName));
            write(fd1, &pid, sizeof(int));
            write(fd1, &length, sizeof(int));

            //Close client to server
            close(fd1);

            //Open server to client and output anyything read
            fd2 = open(readFifo, O_RDONLY);
            read(fd2, &pidReference, sizeof(int));
            printf("Client ID: %d\n\n", pidReference);
            close(fd2);

        }else if(sysCall == 2){//---------------------------------------------------------------------------------------------------------------------------------------

            //Output message and write to server 
            write(fd1, &sysCall, sizeof(int));
            write(fd1, &pidReference, sizeof(int));
            printf("Enter your message: \n");
            scanf("%[^\n]", stringIn);
            flushstdin();
            printf("Enter your message type: \n");
            scanf("%d", &msgType);
            write(fd1, stringIn, sizeof(stringIn));
            write(fd1, &msgType, sizeof(int));
            close(fd1);

            //Open server to client and output anything read
            fd2 = open(readFifo, O_RDONLY);
            read(fd2, serverInString, sizeof(serverInString));
            printf("%s\n\n", serverInString);
            close(fd2);

        }else if(sysCall == 3){//--------------------------------------------------------------------------------------------------------------------------------------

            
            //Output message and write to server
            write(fd1, &sysCall, sizeof(int));
            write(fd1, &pidReference, sizeof(int));
            printf("Enter your message type: \n");
            scanf("%d", &msgType);
            write(fd1, &msgType, sizeof(int));
            close(fd1);

            //Open server to client and output anyything read
            fd2 = open(readFifo, O_RDONLY);
            read(fd2, serverInString, sizeof(serverInString));
            printf("%s\n\n", serverInString);
            close(fd2);

        }else if(sysCall == -1){//--------------------------------------------------------------------------------------------------------------------------------------------


            numPar = 0;
            //Output message and check to see if user input valid / If yes then write to server / If no outut error message
            write(fd1, &sysCall, sizeof(int));
            write(fd1, &numPar, sizeof(int));
            write(fd1, &pidReference, sizeof(int));

            //Close fifo and unlink / Terminate program
            printf("\n");
            close(fd1);
            unlink(readFifo);
            unlink(writeFifo);
            exit(0);

        }else{
            printf("Invalid System Call.\n\n");
        }
        
    }
    return 0;
    
}