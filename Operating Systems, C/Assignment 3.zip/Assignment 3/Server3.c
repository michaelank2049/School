#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#define MAX 50

struct msg_buffer{
    long msgType;
    char msg_Text[200];
}message;

int main(){

    //Label statement to return from a 0 system call
    Begin:
        int fd1, fd2, pid, sysCall, numParam, num, length, pidReference, msgid, msgType;
        char notApplicable[200], fifoName[200], stringIn[200], storedString[200], testString[200], stringOut[200];
        int pidStore[200];
        int count = 1;

        //Create the queue
        key_t key;
        key = ftok("progfile", 65);
        msgid = msgget(key, 0666 | IPC_CREAT);

        //Create read fifo from client
        char* readFifo = "/tmp/mainFifo";
        mkfifo(readFifo, 0666);

        //Create variable for write fifo
        char* writeFifo;
        
    while(1){
        //Variables to convert pid to the full write fifo file path
        char fifoNameFull[200] = "/tmp/fifoClient";
        char fifoNum[200];
    
        //Open the read fifo
        fd1 = open(readFifo, O_RDONLY);

        //Read system call and number of parameters
        read(fd1, &sysCall, sizeof(int));

        if(sysCall == 1){//-------------------------------------------------------------------------------------------------------------------------------------------

            //Read the fifo name, the pid, and the length
            read(fd1, &numParam, sizeof(int));
            read(fd1, fifoName, sizeof(fifoName));
            read(fd1, &pid, sizeof(int));
            read(fd1, &length, sizeof(int));

            //Store pid for further use
            pidStore[count] = pid;
            
            //Create write fifo to client
            writeFifo = fifoName;
            mkfifo(writeFifo, 0666);
            
            //Output the process id, system call, number of parameters, and fifo name
            printf("1. Process ID: %d\n", pidStore[count]);
            printf("2. System Call Number: %d\n", sysCall);
            printf("3. Number 'n' of parameters: %d\n", numParam);
            printf("4. Size of parameter: %d\n", length);
            printf("5. The fifo the client created is named: %s\n\n", fifoName);

            //Close the read fifo
            close(fd1);

            //Open and close fifo to jump back to client
            fd2 = open(writeFifo, O_WRONLY);
            write(fd2, &count, sizeof(int));
            close(fd2);
            
            //Increment counter for next element to store client pid
            count++;

        }else if(sysCall == 2){//--------------------------------------------------------------------------------------------------------------------------------------------
            
            //Read the pid reference number, input string, and message type
            read(fd1, &pidReference, sizeof(int));
            read(fd1, stringIn, sizeof(stringIn));
            read(fd1, &msgType, sizeof(int));

            //Output the process id, system call, the message, and messaeg type
            printf("1. Process ID: %d\n", pidStore[pidReference]);
            printf("2. System Call Number: %d\n", sysCall);
            printf("3. The entered message is: %s\n", stringIn);
            printf("4. The message type is: %d\n\n", msgType);

            //Close the read fifo
            close(fd1);

            //Write to the queue
            message.msgType = (long)msgType;
            strcpy(message.msg_Text, stringIn);

            //Reassign the write fifo to the correct one
            sprintf(fifoNum, "%d", pidStore[pidReference]);
            strcat(fifoNameFull, fifoNum);
            writeFifo = fifoNameFull;
            mkfifo(writeFifo, 0666);

            //If message writes to the queue
            if(msgsnd(msgid, &message, sizeof(message), 0) == 0){

                //Copy the correct message to output string
                strcpy(stringOut, "The message was stored in the queue.");

            }else{ //If message can't write to the queue
                
                //Copy the correct message to output string
                strcpy(stringOut, "The message was unable to be stored in the queue.");

            }

            //Open the server to client fifo, acknowledge the stored value to the client
            fd2 = open(writeFifo, O_WRONLY);
            write(fd2, stringOut, sizeof(stringOut));
            close(fd2);

        }else if(sysCall == 3){//--------------------------------------------------------------------------------------------------------------------------------------------

            //Read the pid reference number and message type
            read(fd1, &pidReference, sizeof(int));
            read(fd1, &msgType, sizeof(int));

            //Output the process id, system call, system call number, and message type
            printf("1. Process ID: %d\n", pidStore[pidReference]);
            printf("2. System Call Number: %d\n", sysCall);
            printf("3. The message type is: %d\n\n", msgType);

            //Close the read fifo
            close(fd1);

            //Read from the queue
            message.msgType = (long)msgType;

            //Reassign the write fifo to the correct one
            sprintf(fifoNum, "%d", pidStore[pidReference]);
            strcat(fifoNameFull, fifoNum);
            writeFifo = fifoNameFull;
            mkfifo(writeFifo, 0666);
            
            //If the message isn't in the queue
            if(msgrcv(msgid, &message, sizeof(message), msgType, IPC_NOWAIT) == -1){

                //Copy the correct message to output string
                strcpy(stringOut, "The message type is not in the queue.");

            }else{//If the message is in the queue

                //Copy the correct message to output string
                strcpy(stringOut, message.msg_Text);
                strcat(stringOut, " was retreived from the queue.");

            }
            
            //Open the server to client fifo, send the stored value to the client
            fd2 = open(writeFifo, O_WRONLY);
            write(fd2, stringOut, sizeof(stringOut));
            close(fd2);

        }else if(sysCall == -1){//-------------------------------------------------------------------------------------------------------------------------------------------

            //Read the pid reference number
            read(fd1, &pidReference, sizeof(int));

            //Output the process id, system call, number of parameters, and array of parameters
            printf("1. Process ID: %d\n", pidStore[pidReference]);
            printf("2. System Call Number: %d\n", sysCall);
            printf("3. Number 'n' of parameter: %d\n", numParam);

            //Close the read fifo
            close(fd1);

            //Reassign the write fifo to the correct one
            sprintf(fifoNum, "%d", pidStore[pidReference]);
            strcat(fifoNameFull, fifoNum);
            writeFifo = fifoNameFull;
            mkfifo(writeFifo, 0666);

            //Unlink fifos and terminate the program
            msgctl(msgid, IPC_RMID, NULL);
            unlink(writeFifo);
            unlink(readFifo);
            exit(0); 
        }
    }
    return 0;
    
}